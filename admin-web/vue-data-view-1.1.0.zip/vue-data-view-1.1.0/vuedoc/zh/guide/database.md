# 数据库说明
```
|--admin					    --------数据库名称
    |--componentconfig			--------组件属性配置字段,可以动态修改属性,
                                        改变client/plugins下的组件的props的值的变化
    |--connection				--------数据库连接字符串
    |--groupcomponent			--------组件分组
    |--image					--------图片列表
    |--menu					    --------菜单列表
    |--project					--------大屏项目信息列表,存储制作大屏的页面信息
    |--token					--------发布作品权限控制,oken字段和用户表的token字段关联,
                                        控制访问链接过期时间
    |--user					    --------用户列表
```
