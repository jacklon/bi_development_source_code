# 快捷键
```
1.复制组件
  单击选中组件, 按ctrl+c
2.删除组件
  单击选中组件, 按enter,delete,backspace中的任意一个
3.获取组件UUID
  单击选中组件, 按alt+c
4.折叠面板
  待更新
```