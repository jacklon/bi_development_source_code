---
home: true
heroText: 可视化编辑器
tagline: 发布大屏项目
actionText: 快速上手 →
actionLink: /zh/guide/
features:
- title: 大屏可视化
  details: 不会编程也可制作精美页面
- title: 可视化编辑器
  details: 方便快捷的组件属性编辑器
- title: 数据栩栩如生
  details: 自由连接数据库，图表展示数据
footer: MIT Licensed | Copyright © 2020 lizhensheng
---

