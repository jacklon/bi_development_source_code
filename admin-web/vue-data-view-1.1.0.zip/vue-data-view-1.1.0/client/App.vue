<template>
  <div id="app" >
    <router-view class="sub-page"/>
  </div>
</template>
<script>
	export default {
	}
</script>
<style lang="scss">
html,body{
  position: relative;
  height: 100%;
}
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  color: #2c3e50;
  position: relative;
  height: 100%;
}
.sub-page{
  position: relative;
  height: 100%;
}
</style>