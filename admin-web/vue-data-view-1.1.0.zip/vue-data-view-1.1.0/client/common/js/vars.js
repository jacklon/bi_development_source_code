export const ALIGNMENT = {
    '左对齐': 'left',
    '居中对齐': 'center',
    '右对齐': 'right'
}