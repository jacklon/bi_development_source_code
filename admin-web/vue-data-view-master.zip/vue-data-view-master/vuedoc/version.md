版本信息

[TOC]



### v0.1.0
- 功能描述:

  - [x] 实现了柱状图的图表配置的简单的封装

- 技术栈

  vue + vue-router + axios + webpack + koa + ES6/7 + stylus + element-ui + youdu(自定义UI)

### v0.1.1
- 功能描述:

  - [x] 实现了数据源的连接配置,支持mysql,oracle

- 技术栈

  mysql+oracledb

  

  

  

  

  

   

  

  

  

  







