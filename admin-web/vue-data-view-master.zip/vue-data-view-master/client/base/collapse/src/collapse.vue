<template>
    <div class="ui-collapse">
        <slot></slot>
    </div>
</template>
<script>
export default {
    name: 'YCollapse',
    data(){
        return {
        }
    },
    props:{
        activeName: String
    },
    created(){
        
    },
    mounted(){

    },
    updated(){

    },
    methods:{
        
    }
}
</script>